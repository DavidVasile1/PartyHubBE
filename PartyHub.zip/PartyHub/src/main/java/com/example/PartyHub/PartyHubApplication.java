package com.example.PartyHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartyHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(PartyHubApplication.class, args);
	}

}
