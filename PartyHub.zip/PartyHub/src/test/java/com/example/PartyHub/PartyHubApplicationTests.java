package com.example.PartyHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartyHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
